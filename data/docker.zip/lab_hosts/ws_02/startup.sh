#!/bin/bash

echo "[*] Starting WS-02"
echo "Role: User Workstation"
echo "IP: 10.0.0.11"
echo "Department: HR"

echo "[*] Starting workstation environment..."

tail -f /dev/null