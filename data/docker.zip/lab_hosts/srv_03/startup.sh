#!/bin/bash

echo "[*] Starting SRV-03"
echo "Role: File Server"
echo "IP: 10.0.0.18"
echo "Department: Finance"

echo "[*] Starting server services..."

tail -f /dev/null