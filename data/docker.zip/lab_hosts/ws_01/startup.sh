#!/bin/bash

echo "[*] Starting WS-01"
echo "Role: User Workstation"
echo "IP: 10.0.0.10"
echo "Department: Finance"

echo "[*] Starting workstation environment..."

tail -f /dev/null