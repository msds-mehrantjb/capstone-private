#!/bin/bash

echo "[*] Starting WS-06"
echo "Role: User Workstation"
echo "IP: 10.0.0.28"
echo "Department: Operations"

echo "[*] Starting workstation environment..."

tail -f /dev/null