#!/bin/bash

echo "[*] Starting SRV-02"
echo "Role: DNS Server"
echo "IP: 10.0.0.3"
echo "Department: IT"

echo "[*] Starting server services..."

tail -f /dev/null