#!/bin/bash

echo "[*] Starting WS-03"
echo "Role: User Workstation"
echo "IP: 10.0.0.12"
echo "Department: Operations"

echo "[*] Starting workstation environment..."

tail -f /dev/null