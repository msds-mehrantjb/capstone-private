#!/bin/bash

echo "[*] Starting WS-04"
echo "Role: User Workstation"
echo "IP: 10.0.0.26"
echo "Department: Sales"

echo "[*] Starting workstation environment..."

tail -f /dev/null