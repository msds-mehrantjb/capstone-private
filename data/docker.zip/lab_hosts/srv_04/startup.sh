#!/bin/bash

echo "[*] Starting SRV-04"
echo "Role: Web Server"
echo "IP: 10.0.0.19"
echo "Department: Marketing"

echo "[*] Starting server services..."

tail -f /dev/null