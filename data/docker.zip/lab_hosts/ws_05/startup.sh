#!/bin/bash

echo "[*] Starting WS-05"
echo "Role: User Workstation"
echo "IP: 10.0.0.27"
echo "Department: HR"

echo "[*] Starting workstation environment..."

tail -f /dev/null