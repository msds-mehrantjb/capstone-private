#!/bin/bash

echo "[*] Starting SRV-01"
echo "Role: Domain Controller"
echo "IP: 10.0.0.2"
echo "Department: IT"

echo "[*] Starting server services..."

tail -f /dev/null