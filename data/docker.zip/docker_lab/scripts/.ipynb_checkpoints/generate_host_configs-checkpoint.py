import json
from pathlib import Path


DATA_DIR = Path(__file__).resolve().parents[2]

MERGED_CONFIG_PATH = DATA_DIR / "lab_output" / "generated_configs" / "merged_lab_config.json"
HOSTS_BASE_DIR = DATA_DIR / "lab_hosts"


def load_json(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def generate_startup_script(host):
    lines = [
        "#!/bin/bash",
        "",
        f'echo "[*] Starting {host["hostname"]}"',
        f'echo "Role: {host["role"]}"',
        f'echo "IP: {host["ip_address"]}"',
        f'echo "Department: {host["department"]}"',
        "",
    ]

    if host["device_type"].lower() == "server":
        lines.append('echo "[*] Starting server services..."')

    else:
        lines.append('echo "[*] Starting workstation environment..."')

    lines.append("")
    lines.append("tail -f /dev/null")

    return "\n".join(lines)


def generate_services_conf(host):
    return {
        "open_ports": host["open_ports"],
        "running_services": host["running_services"],
        "installed_software": host["installed_software"],
        "installed_roles": host["installed_roles"]
    }


def main():
    if not MERGED_CONFIG_PATH.exists():
        print("ERROR: merged config not found")
        return

    config = load_json(MERGED_CONFIG_PATH)

    total_hosts = 0

    for subnet in config["subnets"]:
        for host in subnet["hosts"]:
            hostname = host["hostname"].lower().replace("-", "_")
            host_dir = HOSTS_BASE_DIR / hostname

            host_dir.mkdir(parents=True, exist_ok=True)

            # 1. host_config.json
            host_config_path = host_dir / "host_config.json"
            write_json(host_config_path, host)

            # 2. services.conf
            services_path = host_dir / "services.conf"
            write_json(services_path, generate_services_conf(host))

            # 3. startup.sh
            startup_path = host_dir / "startup.sh"
            with open(startup_path, "w", encoding="utf-8") as f:
                f.write(generate_startup_script(host))

            total_hosts += 1

    print(f"[✓] Generated configs for {total_hosts} hosts")


if __name__ == "__main__":
    main()