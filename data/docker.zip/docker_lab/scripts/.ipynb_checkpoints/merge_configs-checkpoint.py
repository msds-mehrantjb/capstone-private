import json
from pathlib import Path


# Current file: data/docker_lab/scripts/merge_configs.py
DATA_DIR = Path(__file__).resolve().parents[2]

OU_PATH = DATA_DIR / "work" / "2026" / "OU.json"
ASSET_DETAILS_PATH = DATA_DIR / "work" / "2026" / "AssetDetails.json"
OUTPUT_PATH = DATA_DIR / "lab_output" / "generated_configs" / "merged_lab_config.json"


def load_json(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def host_id_to_hostname(host_id: str) -> str:
    if host_id.startswith("Server_"):
        return host_id.replace("Server_", "SRV-")
    if host_id.startswith("WS_"):
        return host_id.replace("WS_", "WS-")
    return host_id


def behavior_profile_from_host(asset_host: dict) -> str:
    role = asset_host.get("role", "").strip().lower()
    hostname = asset_host.get("hostname", "").strip().lower()

    if role == "domain controller":
        return "domain_controller"
    if role == "dns server":
        return "dns_dhcp"
    if role == "file server":
        return "file_server"
    if role == "web server":
        return "web_server"

    if hostname == "ws-01":
        return "finance_workstation"
    if hostname == "ws-02":
        return "hr_workstation"
    if hostname == "ws-03":
        return "operations_workstation"
    if hostname == "ws-04":
        return "sales_workstation"
    if hostname == "ws-05":
        return "dev_workstation"
    if hostname == "ws-06":
        return "datascience_workstation"

    return "generic_workstation"


def published_ports(profile: str, nat_type: str):
    if "Static" not in nat_type:
        return []

    mapping = {
        "domain_controller": ["1053:53", "1389:389", "1445:445"],
        "dns_dhcp": ["2053:53"],
        "file_server": ["2445:445"],
        "web_server": ["8080:80", "8443:443"],
    }
    return mapping.get(profile, [])


def subnet_cidr_from_gateway(gateway_ip: str) -> str:
    if gateway_ip == "10.0.0.1":
        return "10.0.0.0/28"
    if gateway_ip == "10.0.0.17":
        return "10.0.0.16/28"
    raise ValueError(f"Unknown gateway IP: {gateway_ip}")


def main():
    ou = load_json(OU_PATH)
    asset_details = load_json(ASSET_DETAILS_PATH)

    asset_lookup = {}
    for network in asset_details["networks"]:
        for subnet in network["subnets"]:
            for host in subnet["hosts"]:
                asset_lookup[host["hostname"]] = host

    merged = {
        "lab_name": "enterprise_lab",
        "year": asset_details.get("year"),
        "public_gateway_ip": ou["nat_configuration"]["public_gateway_ip"],
        "private_range": ou["nat_configuration"]["internal_network_summary"]["private_range"],
        "subnets": []
    }

    for subnet in ou["nat_configuration"]["subnets"]:
        merged_subnet = {
            "name": subnet["name"],
            "cidr": subnet_cidr_from_gateway(subnet["gateway_internal"]),
            "gateway_internal": subnet["gateway_internal"],
            "docker_network_name": subnet["name"].lower() + "_net",
            "hosts": []
        }

        for ou_host in subnet["hosts"]:
            hostname = host_id_to_hostname(ou_host["id"])
            asset_host = asset_lookup.get(hostname)

            if not asset_host:
                print(f"Warning: host {hostname} not found in AssetDetails.json")
                continue

            detail = asset_host.get("detail", {})
            business_context = detail.get("business_context", {})
            device_profile = detail.get("device_profile", {})
            technical_indicators = detail.get("technical_indicators", {})

            profile = behavior_profile_from_host(asset_host)

            merged_host = {
                "lab_id": ou_host["id"],
                "hostname": asset_host["hostname"],
                "ip_address": asset_host["ip_address"],
                "nat_type": ou_host["nat_type"],
                "device_type": asset_host.get("device_type", ""),
                "status": asset_host.get("status", ""),
                "role": asset_host.get("role", ""),
                "cia_impact": asset_host.get("cia_impact", {}),
                "department": business_context.get("department", ""),
                "business_function": business_context.get("business_function", ""),
                "criticality": business_context.get("criticality", ""),
                "os_type": device_profile.get("os_type", ""),
                "os_version": device_profile.get("os_version", ""),
                "is_domain_joined": device_profile.get("is_domain_joined", False),
                "hostname_pattern": device_profile.get("hostname_pattern", ""),
                "open_ports": technical_indicators.get("open_ports", []),
                "running_services": technical_indicators.get("running_services", []),
                "installed_roles": technical_indicators.get("installed_roles", []),
                "installed_software": technical_indicators.get("installed_software", []),
                "behavior_profile": profile,
                "published_ports": published_ports(profile, ou_host["nat_type"])
            }

            merged_subnet["hosts"].append(merged_host)

        merged["subnets"].append(merged_subnet)

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2)

    print(f"Merged configuration created at: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()