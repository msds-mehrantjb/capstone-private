import json
from pathlib import Path


DATA_DIR = Path(__file__).resolve().parents[2]
MERGED_CONFIG_PATH = DATA_DIR / "lab_output" / "generated_configs" / "merged_lab_config.json"
OUTPUT_DIR = DATA_DIR / "lab_output" / "generated_compose"
OUTPUT_PATH = OUTPUT_DIR / "docker-compose.yml"


def load_json(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def service_build_context(host):
    profile = host["behavior_profile"]

    mapping = {
        "domain_controller": "lab_services/domain_controller",
        "dns_dhcp": "lab_services/dns",
        "file_server": "lab_services/file_server",
        "web_server": "lab_services/web_server",
        "finance_workstation": "lab_services/finance_ws",
        "hr_workstation": "lab_services/hr_ws",
        "operations_workstation": "lab_services/operations_ws",
        "sales_workstation": "lab_services/sales_ws",
        "dev_workstation": "lab_services/dev_ws",
        "datascience_workstation": "lab_services/datascience_ws",
        "generic_workstation": "lab_services/operations_ws"
    }

    return mapping.get(profile, "lab_services/operations_ws")

def env_lines(host):
    lines = [
        f"HOSTNAME={host['hostname']}",
        f"HOST_ROLE={host['role']}",
        f"DEVICE_TYPE={host['device_type']}",
        f"DEPARTMENT={host['department']}",
        f"BUSINESS_FUNCTION={host['business_function']}",
        f"CRITICALITY={host['criticality']}",
        f"OS_TYPE={host['os_type']}",
        f"OS_VERSION={host['os_version']}",
        f"BEHAVIOR_PROFILE={host['behavior_profile']}",
        f"IP_ADDRESS={host['ip_address']}",
        f"NAT_TYPE={host['nat_type']}",
    ]
    return lines


def write_compose(cfg: dict):
    lines = []
    lines.append('version: "3.9"')
    lines.append("")
    lines.append("services:")

    # gateway
    lines.append("  gateway:")
    lines.append("    build:")
    lines.append("      context: ../../lab_services/gateway")
    lines.append("    container_name: gateway")
    lines.append("    privileged: true")
    lines.append("    cap_add:")
    lines.append("      - NET_ADMIN")
    lines.append('    sysctls:')
    lines.append('      net.ipv4.ip_forward: "1"')
    lines.append("    networks:")

    for subnet in cfg["subnets"]:
        lines.append(f"      {subnet['docker_network_name']}:")
        lines.append(f"        ipv4_address: {subnet['gateway_internal']}")

    lines.append("")

    # hosts
    for subnet in cfg["subnets"]:
        net_name = subnet["docker_network_name"]

        for host in subnet["hosts"]:
            service_name = host["hostname"].lower().replace("-", "_")

            lines.append(f"  {service_name}:")
            lines.append("    build:")
            lines.append(f"      context: ../../{service_build_context(host)}")
            lines.append(f"    container_name: {service_name}")
            lines.append(f"    hostname: {host['hostname']}")
            lines.append("    environment:")
            for entry in env_lines(host):
                lines.append(f"      - {entry}")

            if host["published_ports"]:
                lines.append("    ports:")
                for port in host["published_ports"]:
                    lines.append(f'      - "{port}"')

            lines.append("    networks:")
            lines.append(f"      {net_name}:")
            lines.append(f"        ipv4_address: {host['ip_address']}")
            lines.append("")

    lines.append("networks:")
    for subnet in cfg["subnets"]:
        docker_gateway = "10.0.0.14" if subnet["cidr"] == "10.0.0.0/28" else "10.0.0.30"
        lines.append(f"  {subnet['docker_network_name']}:")
        lines.append("    driver: bridge")
        lines.append("    ipam:")
        lines.append("      config:")
        lines.append(f"        - subnet: {subnet['cidr']}")
        lines.append(f"          gateway: {docker_gateway}")
        lines.append("")
    return "\n".join(lines)


def main():
    if not MERGED_CONFIG_PATH.exists():
        print(f"ERROR: merged config not found: {MERGED_CONFIG_PATH}")
        raise SystemExit(1)

    cfg = load_json(MERGED_CONFIG_PATH)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    compose_text = write_compose(cfg)

    with open(OUTPUT_PATH, "w", encoding="utf-8", newline="\n") as f:
        f.write(compose_text)

    print(f"[✓] Docker Compose generated: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()