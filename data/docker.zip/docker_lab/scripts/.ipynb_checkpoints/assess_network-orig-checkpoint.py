import subprocess
import json
import re
import ipaddress
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[2]
OUTPUT_FILE = DATA_DIR / "work" / "2026" / "DockerAssetInventory.json"

SUBNETS = {
    "Subnet_A": {
        "cidr": "10.0.0.0/28",
        "gateway": "10.0.0.1",
        "docker_network_gateway": "10.0.0.14"
    },
    "Subnet_B": {
        "cidr": "10.0.0.16/28",
        "gateway": "10.0.0.17",
        "docker_network_gateway": "10.0.0.30"
    }
}

SCANNER_CONTAINER = "ws_01"


def run_nmap(subnet: str) -> str:
    print(f"[+] Running nmap inside scanner on {subnet}")

    result = subprocess.run(
        ["docker", "exec", SCANNER_CONTAINER, "nmap", "-sn", subnet],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        print("[!] nmap error:")
        print(result.stderr)

    print("----- RAW NMAP OUTPUT -----")
    print(result.stdout)
    print("---------------------------")

    return result.stdout


def parse_nmap(output: str) -> list[dict]:
    hosts = []

    for line in output.splitlines():
        line = line.strip()

        if line.startswith("Nmap scan report for"):
            match = re.match(r"Nmap scan report for (.+?) \(([\d.]+)\)$", line)
            if match:
                hostname = match.group(1).strip()
                ip = match.group(2).strip()
            else:
                ip = line.split()[-1].strip()
                hostname = ""

            hosts.append({
                "hostname": hostname,
                "ip_address": ip
            })

    return hosts


def resolve_hostname(ip: str) -> str:
    result = subprocess.run(
        ["docker", "exec", SCANNER_CONTAINER, "getent", "hosts", ip],
        capture_output=True,
        text=True
    )

    if result.returncode == 0 and result.stdout.strip():
        parts = result.stdout.strip().split()
        if len(parts) >= 2:
            return parts[1].strip()

    return ""


def normalize_hostname(hostname: str) -> str:
    hostname = hostname.strip()

    if not hostname:
        return ""

    if "." in hostname:
        hostname = hostname.split(".")[0]

    return hostname


def build_asset(host: dict) -> dict:
    hostname = normalize_hostname(host.get("hostname", ""))
    ip = host.get("ip_address", "").strip()

    if not hostname:
        hostname = normalize_hostname(resolve_hostname(ip))

    return {
        "hostname": hostname,
        "ip_address": ip,
        "status": "Active",
        "detail": {}
    }


def main() -> None:
    result = {
        "meta": {
            "year": 2026,
            "name": "Asset Inventory & CIA",
            "submitted": False,
            "read_only": False
        },
        "subnets": []
    }

    for subnet_name, subnet_info in SUBNETS.items():
        cidr = subnet_info["cidr"]
        gateway = subnet_info["gateway"]
        docker_network_gateway = subnet_info["docker_network_gateway"]

        excluded_ips = {gateway.strip(), docker_network_gateway.strip()}

        print(f"[+] Scanning {cidr}")
        output = run_nmap(cidr)
        discovered_hosts = parse_nmap(output)

        assets = []
        for host in discovered_hosts:
            ip = host["ip_address"].strip()

            if ip in excluded_ips:
                continue

            assets.append(build_asset(host))

        assets = sorted(assets, key=lambda x: ipaddress.ip_address(x["ip_address"]))

        print(f"[+] Total hosts in {subnet_name}: {len(assets)}")

        subnet_entry = {
            "id": subnet_name,
            "subnet_mask": cidr,
            "location": {
                "name": gateway,
                "ip_range": cidr
            },
            "assets": assets
        }

        result["subnets"].append(subnet_entry)

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print(f"[✓] DockerAssetInventory.json generated at: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()