from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[2]

targets = [
    DATA_DIR / "lab_services" / "gateway" / "init.sh",
    DATA_DIR / "lab_services" / "domain_controller" / "init.sh",
    DATA_DIR / "lab_services" / "dns" / "init.sh",
    DATA_DIR / "lab_services" / "file_server" / "init.sh",
    DATA_DIR / "lab_services" / "web_server" / "init.sh",
    DATA_DIR / "lab_services" / "finance_ws" / "init.sh",
    DATA_DIR / "lab_services" / "hr_ws" / "init.sh",
    DATA_DIR / "lab_services" / "operations_ws" / "init.sh",
    DATA_DIR / "lab_services" / "sales_ws" / "init.sh",
    DATA_DIR / "lab_services" / "dev_ws" / "init.sh",
    DATA_DIR / "lab_services" / "datascience_ws" / "init.sh",
]

for path in targets:
    if not path.exists():
        print(f"Missing: {path}")
        continue

    text = path.read_text(encoding="utf-8", errors="ignore")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    path.write_text(text, encoding="utf-8", newline="\n")
    print(f"Fixed: {path}")

print("Done.")