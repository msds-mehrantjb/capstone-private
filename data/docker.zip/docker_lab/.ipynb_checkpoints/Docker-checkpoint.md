# Docker-Based Enterprise Network Lab

## 1. Overview

I created a Docker-based enterprise network lab to simulate a small segmented enterprise environment for my capstone project. The goal of the lab was to build a repeatable, JSON-driven network that supports:

- asset discovery  
- subnet-based network segmentation  
- host role simulation  
- routing through a gateway  
- active host scanning  
- future integration with Asset Inventory & CIA, vulnerability, and risk analysis modules  

The lab was designed around two main JSON files:

- `OU.json` for network architecture and subnet layout  
- `AssetDetails.json` for host specifications, roles, and technical indicators  

---

## 2. Design Goals

The lab was built to satisfy the following:

- preserve original JSON files without modification  
- run on Windows using Docker Desktop  
- simulate enterprise segmentation  
- support routing between subnets  
- generate `AssetInventory.json` automatically  
- serve as a live backend for the capstone system  

---

## 3. Source Files and Their Roles

### OU.json

Used as the authoritative source for:

- network structure  
- subnet layout  
- gateway addresses  
- host grouping  
- NAT behavior  

Defines two subnets:

- `Subnet_A` → gateway `10.0.0.1`  
- `Subnet_B` → gateway `10.0.0.17`  

---

### AssetDetails.json

Used as the authoritative source for:

- hostname  
- IP address  
- device type  
- role  
- CIA impact  
- operating system  
- open ports  
- running services  
- installed software  
- business context  

Defines key hosts such as:

- Domain Controller  
- DNS Server  
- File Server  
- Web Server  
- Workstations  

---

## 4. Final Network Architecture

### Subnet A
- Network: `10.0.0.0/28`  
- Gateway: `10.0.0.1`  

Assets:
- SRV-01 → 10.0.0.2  
- SRV-02 → 10.0.0.3  
- WS-01 → 10.0.0.10  
- WS-02 → 10.0.0.11  
- WS-03 → 10.0.0.12  

---

### Subnet B
- Network: `10.0.0.16/28`  
- Gateway: `10.0.0.17`  

Assets:
- SRV-03 → 10.0.0.18  
- SRV-04 → 10.0.0.19  
- WS-04 → 10.0.0.26  
- WS-05 → 10.0.0.27  
- WS-06 → 10.0.0.28  

---

## 5. Folder Structure

```text
data/
├── docker_lab/
│   ├── scripts/
│   │   ├── merge_configs.py
│   │   ├── validate_lab.py
│   │   ├── generate_host_configs.py
│   │   ├── generate_compose.py
│   │   ├── assess_network.py
│
├── lab_services/
│   ├── gateway/
│   ├── domain_controller/
│   ├── dns/
│   ├── file_server/
│   ├── web_server/
│   ├── finance_ws/
│   ├── hr_ws/
│   ├── operations_ws/
│   ├── sales_ws/
│   ├── dev_ws/
│   └── datascience_ws/
│
├── lab_hosts/
│   ├── srv_01/
│   ├── srv_02/
│   ├── srv_03/
│   ├── srv_04/
│   ├── ws_01/
│   ├── ws_02/
│   ├── ws_03/
│   ├── ws_04/
│   ├── ws_05/
│   └── ws_06/
│
├── lab_output/
│   ├── generated_configs/
│   ├── generated_compose/
│   ├── generated_inventory/
│
└── work/
    └── 2026/
        ├── OU.json
        ├── AssetDetails.json
        ├── AssetInventory.json


```
## 6. Lab Build Process

### Step 1: Create Folder Structure

Structured directories were created under:

data/

Key folders:

- data/docker_lab/scripts/
- data/lab_services/
- data/lab_hosts/
- data/lab_output/

---

### Step 2: Merge Configuration

**Script:**
data/docker_lab/scripts/merge_configs.py

A Python script combines:

- network structure from:
  data/work/2026/OU.json

- asset definitions from:
  data/work/2026/AssetDetails.json

**Output:**
data/lab_output/generated_configs/merged_lab_config.json

---

### Step 3: Validate Configuration

**Script:**
data/docker_lab/scripts/validate_lab.py

Validation checks:

- subnet correctness  
- gateway placement  
- host IP validity  
- uniqueness of IPs and hostnames  

---

### Step 4: Generate Host Configurations

**Script:**
data/docker_lab/scripts/generate_host_configs.py

Each host gets generated files under:

data/lab_hosts/<hostname>/

Files created:

- host_config.json  
- service configuration  
- startup script (startup.sh)  

---

### Step 5: Generate Docker Compose

**Script:**
data/docker_lab/scripts/generate_compose.py

**Output:**
data/lab_output/generated_compose/docker-compose.yml

Includes:

- gateway container  
- server containers  
- workstation containers  
- network definitions  
- static IP assignments  

---

### Step 6: Create Service Containers

Service definitions located in:

data/lab_services/

Each service folder contains:

- Dockerfile  
- init.sh  

Example:

- data/lab_services/gateway/  
- data/lab_services/domain_controller/  
- data/lab_services/dns/  
- data/lab_services/file_server/  
- data/lab_services/web_server/  
- data/lab_services/finance_ws/  
- data/lab_services/hr_ws/  
- data/lab_services/operations_ws/  
- data/lab_services/sales_ws/  
- data/lab_services/dev_ws/  
- data/lab_services/datascience_ws/  

These simulate enterprise roles.

---

### Step 7: Start the Lab

Docker Compose builds and runs all containers.

Compose file:

data/lab_output/generated_compose/docker-compose.yml

---

### Step 8: Enable Routing

Routing is configured using:

- gateway container (init.sh)  
- workstation startup scripts  

Files:

- data/lab_services/gateway/init.sh  
- data/lab_services/*_ws/init.sh  

Routing enables:

- Subnet A ↔ Subnet B communication  
- gateway-based traffic forwarding  

---

## 7. Important Code Components

### A. Merge Script

data/docker_lab/scripts/merge_configs.py

Combines OU and Asset data into a unified configuration.

---

### B. Validation Script

data/docker_lab/scripts/validate_lab.py

Ensures correctness before deployment.

---

### C. Compose Generator

data/docker_lab/scripts/generate_compose.py

Creates Docker infrastructure automatically.

---

### D. Gateway Script

data/lab_services/gateway/init.sh

Handles:

- routing logic  
- packet forwarding  
- gateway behavior  

---

### E. Workstation Scripts

data/lab_services/*_ws/init.sh

Add routing rules for:

- inter-subnet communication  
- default gateway usage  

---

### F. assess_network.py

data/docker_lab/scripts/assess_network.py

Performs:

- live network scanning  
- host discovery  
- generation of:

data/work/2026/AssetInventory.json

---

## 8. Commands to Run and Activate the Lab

### Navigate to Compose Folder

```cmd
cd C:\Users\mehra\Capstone-main\data\lab_output\generated_compose
```

### Start Lab

```cmd
docker compose up -d --build
```

### Stop Lab
```cmd
docker compose down
```

### Check Running Containers
```cmd
docker ps
```

### Test Connectivity
```cmd
docker exec -it ws_01 ping 10.0.0.2
docker exec -it ws_01 ping 10.0.0.18
docker exec -it ws_04 ping 10.0.0.2
```

### Run Asset Discovery
```cmd
cd C:\Users\mehra\Capstone-main\data
python docker_lab\scripts\assess_network.py
```

### Manual Network Scan
```cmd
docker exec -it ws_01 nmap -sn 10.0.0.0/28
docker exec -it ws_01 nmap -sn 10.0.0.16/28
```


