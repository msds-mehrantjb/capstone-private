#!/bin/bash
service nginx start || true
echo "[*] Simulated Web Server started"
tail -f /dev/null
