#!/bin/bash

echo "[*] Gateway container starting"

# Enable forwarding (ignore failure on some systems)
echo 1 > /proc/sys/net/ipv4/ip_forward || true

# Clear old rules
iptables -F || true
iptables -t nat -F || true

# Allow forwarding
iptables -A FORWARD -i eth0 -o eth1 -j ACCEPT || true
iptables -A FORWARD -i eth1 -o eth0 -j ACCEPT || true

# NAT (optional but useful)
iptables -t nat -A POSTROUTING -j MASQUERADE || true

echo "[*] Routing enabled"

tail -f /dev/null