#!/bin/bash
set -e
echo "[*] Gateway container starting"
sysctl -w net.ipv4.ip_forward=1
iptables -t nat -A POSTROUTING -j MASQUERADE || true
iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT || true
iptables -A FORWARD -s 10.0.0.0/24 -j ACCEPT || true
echo "[*] Gateway ready"
tail -f /dev/null
