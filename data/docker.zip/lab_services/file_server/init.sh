#!/bin/bash
mkdir -p /srv/share
chmod 777 /srv/share
echo "[*] Simulated File Server started"
tail -f /dev/null
