#!/bin/bash
echo "[*] Simulated Domain Controller started"
tail -f /dev/null
