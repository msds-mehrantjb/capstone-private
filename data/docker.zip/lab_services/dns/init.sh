#!/bin/bash
echo "[*] Simulated DNS server started"
tail -f /dev/null
