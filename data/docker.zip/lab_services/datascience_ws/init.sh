#!/bin/bash
echo "[*] Workstation started"
echo "Hostname: $HOSTNAME"
echo "Role: $HOST_ROLE"
echo "Department: $DEPARTMENT"
echo "Business Function: $BUSINESS_FUNCTION"
echo "Profile: $BEHAVIOR_PROFILE"
tail -f /dev/null
