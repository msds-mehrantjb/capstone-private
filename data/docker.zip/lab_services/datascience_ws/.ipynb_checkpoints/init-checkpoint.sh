#!/bin/bash
echo "[*] Workstation started"
echo "Hostname: $HOSTNAME"
echo "Role: $HOST_ROLE"

ip route add 10.0.0.0/28 via 10.0.0.17 || true

tail -f /dev/null